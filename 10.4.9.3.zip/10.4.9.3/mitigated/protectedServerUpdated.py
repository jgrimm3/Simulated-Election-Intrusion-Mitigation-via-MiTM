#basic tcp server

import socket
from Crypto.Hash import HMAC
from Crypto.Cipher import AES

#shared keys assumed private
macKey = b'EAD38649A3D3F68E'
aesKey = b'D83B7A9E7C6F2A10'


add_croc = ("update votes set crocs = crocs + 1")
                    
add_yeezy = ("update votes set yeezy = yeezy + 1")


sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print ("created socket")

port = 5080

#empty host field such that listen on requests from any computer on network
sock.bind(('', port))
print ('socket bound')

#listen for connections keeping a backlog of 5, practical for multiple lace results flooding at once
sock.listen(5)
print ("socket is listening")

#wait for connection 
while True :
    #connection found
    connect,  addr = sock.accept()
    print ('connected to ',  addr)
    
    #recieve data
    crypto = connect.recv(1024)
    print("Encrypted Packet Received")
    print (crypto)
    print("\n")


    #Begin decrypting
    #first isolate first 16 bytes for iv, next 16 for the Mac, and last 16 for the message
    iv = crypto[:16] 
  
    toDecode = crypto[16:]
    print("Encrypted Vote")
    print(toDecode)

    #use iv to decrypt message and mac
    cipher = AES.new(aesKey,  AES.MODE_CBC, iv)
    decrypted = cipher.decrypt(toDecode)
    print("decrypted message")
    print (decrypted)

    mac = decrypted[:32]
    print ("Decrypted MAC")
    print (mac)

    padMsg = decrypted[32:]
    pTextMsg = padMsg.decode()
    
    if pTextMsg[0] == "c":
        vote = pTextMsg[:4]
        vote = vote.encode()
    elif pTextMsg[0] == "y":
        vote = pTextMsg[:5]
        vote = vote.encode()
    else:
        vote = b'yeezy'

    print ("Decrypted Vote")
    print(vote)

    #generate hmac on recieved vote and compare
    calcMac = HMAC.new(macKey,  vote)
    print ("Calculating MAC on Vote")
    print (calcMac.hexdigest())

    print("\n")
    print("Comparing MACS")
    if (mac == calcMac.hexdigest().encode()):
        print("Vote Successful")
        connect.sendall(b'Valid Vote accepted')
    else:
        print("Vote Compromised, failed Mac")
 
    
connect.close()

sock.close()
del sock
