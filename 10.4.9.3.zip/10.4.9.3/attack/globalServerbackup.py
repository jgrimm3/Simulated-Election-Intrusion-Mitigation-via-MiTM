#basic tcp server

import socket

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print ("created socket")

port = 5080

#empty host field such that listen on requests from any computer on network
sock.bind(('', port))
print ('socket bound')

#listen for connections keeping a backlog of 5, practical for multiple lace results flooding at once
sock.listen(5)
print ("socket is listening")

#connection found
connect,  addr = sock.accept()
print ('connected to ',  addr)

print("Recieved Vote")
while True:
    #recieve data
    laceResult = connect.recv(1024).decode()
    print (laceResult)

    if laceResult == "croc":
        print('Recorded vote for Croc')
        break

    elif laceResult == "yeezy":
        print('Recorded vote for Yeezy')
        break

connect.close()

sock.close()
del sock
