#basic tcp server
import time
import socket

while True:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    print ("created socket")

    port = 5080

    #empty host field such that listen on requests from any computer on network
    sock.bind(('', port))
    print ('socket bound')

    #listen for connections keeping a backlog of 5, practical for multiple lace results flooding at once
    sock.listen(5)
    print ("listening...")

    #connection found
    connect,  addr = sock.accept()
    print ('connected to ',  addr)
    print("\n")
    print("Recieved Vote")
    #recieve data
    laceResult = connect.recv(1024).decode()
    #print (laceResult)

    if laceResult == "croc":
        print('Recorded vote for croc')
        #break

    elif laceResult == "yeezy":
        print('Recorded vote for yeezy')
        #break

    connect.close()

    sock.close()
    del sock
    time.sleep(1)
