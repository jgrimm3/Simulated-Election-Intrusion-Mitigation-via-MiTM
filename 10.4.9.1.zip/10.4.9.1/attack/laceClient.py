#baseLace
import socket
import sys

# Check for valud command line arguments
if len(sys.argv) == 2:
    outcome = sys.argv[1]
else:
    print('Invalid program usage!')
    exit()

if sys.argv[1] == "croc" or sys.argv[1] == "yeezy":
    laceVote = sys.argv[1]
else:
    print('Invalid candidate, aborting')
    exit()

sock = socket.socket(socket.AF_INET,  socket.SOCK_STREAM)

port = 6000

sock.connect(('10.4.9.2',  port))

#send Lace results
sock.sendall(laceVote.encode())

sock.close
del sock
