#baseLace

import socket
import array
import sys
from Crypto.Cipher import AES
from Crypto import Random
from Crypto.Hash import HMAC

laceVote = sys.argv[1]

#apply padding for AES blocks and set web crawler
if laceVote == "croc":
    padNum = '716c8ad64039'
    croc = True
    yeezy = False
elif laceVote == "yeezy":
    padNum = '40A6B93EF52'
    croc = False
    yeezy = True

#generate message authentication code
macKey = b'EAD38649A3D3F68E'
mac = HMAC.new(macKey,  laceVote.encode())
print ("Calculated MAC")
print (mac.hexdigest())

#concatenate mac onto front of message, know it will be first 16 bytes
macdMessage = mac.hexdigest() + laceVote + padNum

#encrype mac and plaintext vote using different key
aesKey = b'D83B7A9E7C6F2A10'
iv = Random.new().read(AES.block_size)
cipher = AES.new(aesKey,  AES.MODE_CBC, iv)

encVote = iv + cipher.encrypt(macdMessage)
print("Encrypted Vote and Signature")
print (encVote)


sock = socket.socket(socket.AF_INET,  socket.SOCK_STREAM)

port = 5080

sock.connect(('10.4.9.3',  port))

#send Lace results
sock.send(encVote)

#write results to backup local database
db = open("db.txt", "r+")
votes = db.read()
votecnt = array.array('i', [0,0])
out = votes.split('\n')
i = 0
j = 0

while i < len(out):
    if "Yeezy" in out[i] or "Crocs" in out[i]:
        votecnt[j] = int(''.join(filter(str.isdigit, out[i])))
        j += 1
    i += 1
db.close()

if yeezy:
    votecnt[0] += 1
if croc:
    votecnt[1] += 1

db = open("db.txt", "w+")
db.write('Yeezys: ' + str(votecnt[0]) + '\nCrocs: ' + str(votecnt[1]))
db.close()

sock.close
del sock
